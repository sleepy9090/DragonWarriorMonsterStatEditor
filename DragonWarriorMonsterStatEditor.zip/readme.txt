﻿DragonWarriorMonsterStatEditor 1.0.0.10546
Coded by: Shawn M. Crawford [sleepy9090]
March 17, 2018

-Requires .NET Framework 3.5

DragonWarriorMonsterStatEditor 
Program to edit the stats of the monsters in the NES ROM Dragon Warrior.

-Tested with headered Dragon Warrior (U) (PRG0) [!].nes ROM.
-Tested with headered Dragon Warrior (U) (PRG1) [!].nes ROM.

Feel free to send bugs to sleepy3d@email.com or file them on github: https://github.com/sleepy9090

Version: 1.0.0.10546 March 17, 2018
-initial version


